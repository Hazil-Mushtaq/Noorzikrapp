/* ============================================================
   NOOR v2.1 — app.js
   Developer: Ariyan Mushtaq | Ariyanmushtaq@proton.me

   KEY FIXES:
   ✅ Single-tap = single count (no double binding anywhere)
   ✅ Zero inline onclick in HTML — all events bound here once
   ✅ Only one Settings button (in nav tab bar)
   ✅ Vibration works on Android
   ✅ Undo & Reset fully functional

   NEW FEATURES:
   ✅ Today's zikr count tracker
   ✅ Quick zikr picker on Tasbih screen
   ✅ Large Arabic text toggle
   ✅ Completion alert toggle
   ✅ Progress stats in Settings
   ✅ Info banner on Darood
   ✅ Delete custom zikr
   ============================================================ */

'use strict';

/* ═══════════════════════════════════════════════════════════
   DATA
═══════════════════════════════════════════════════════════ */
const DATA = {
  zikr: [
    { id:'z1',  name:'Tasbeeh',            urdu:'تسبیح',          arabic:'سُبْحَانَ اللّٰهِ',                                                                                                         roman:'SubhanAllah',                          meaning:'Allah har kami se paak hai. Glory be to Allah.',                             hadith:'SubhanAllah 100× → 1,000 rewards, 1,000 sins erased. (Muslim)',                       badge:'sahih',     cat:'morning' },
    { id:'z2',  name:'Tahmeed',            urdu:'تحمید',          arabic:'الْحَمْدُ لِلّٰهِ',                                                                                                         roman:'Alhamdulillah',                        meaning:'Tamam tareef Allah ke liye hai. All praise belongs to Allah.',               hadith:'Alhamdulillah fills the scales of Judgement Day. (Muslim)',                           badge:'sahih',     cat:'morning' },
    { id:'z3',  name:'Takbeer',            urdu:'تکبیر',          arabic:'اللّٰهُ أَكْبَرُ',                                                                                                          roman:'Allahu Akbar',                         meaning:'Allah sab se bada hai. Allah is the Greatest.',                              hadith:'More beloved to Allah than all the world. (Muslim)',                                  badge:'sahih',     cat:'morning' },
    { id:'z4',  name:'Kalima Tayyiba',     urdu:'کلمہ طیبہ',      arabic:'لَا إِلٰهَ إِلَّا اللّٰهُ',                                                                                                roman:'La ilaha illallah',                    meaning:'Allah ke siwa koi mabood nahi.',                                             hadith:'Best Zikr is La ilaha illallah. (Tirmidhi — Sahih)',                                  badge:'powerful',  cat:'all'     },
    { id:'z5',  name:'Hawqala',            urdu:'لا حول',         arabic:'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللّٰهِ',                                                                               roman:'La hawla wa la quwwata illa billah',    meaning:'Koi taqat nahi magar Allah ke zariye.',                                     hadith:'A treasure from the treasures of Jannah. (Bukhari, Muslim)',                          badge:'powerful',  cat:'all'     },
    { id:'z6',  name:'Hasbi Allah',        urdu:'حسبی اللہ',      arabic:'حَسْبِيَ اللّٰهُ وَنِعْمَ الْوَكِيلُ',                                                                                    roman:"HasbiAllahu wa ni'mal wakeel",          meaning:'Allah kaafi hai, woh behtareen wakeel hai.',                                 hadith:'Ibrahim ﷺ said this when thrown into fire. (Bukhari)',                                badge:'protection',cat:'morning' },
    { id:'z7',  name:'Heavy on Scale',     urdu:'میزان میں بھاری', arabic:'سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ، سُبْحَانَ اللّٰهِ الْعَظِيمِ',                                                           roman:'SubhanAllahi wa bihamdihi, SubhanAllahil Azeem', meaning:'Allah paak hai uski hamd ke saath, Allah Azeem paak hai.',              hadith:'Light on tongue, heavy on scale, beloved to Rahman. (Bukhari, Muslim)',               badge:'powerful',  cat:'all'     },
    { id:'z8',  name:'Four Grand Zikr',    urdu:'چار عظیم ذکر',   arabic:'سُبْحَانَ اللّٰهِ وَالْحَمْدُ لِلّٰهِ وَلَا إِلٰهَ إِلَّا اللّٰهُ وَاللّٰهُ أَكْبَرُ',                                 roman:'SubhanAllahi walhamdulillahi wa la ilaha illallahu wallahu akbar', meaning:'Allah paak, tamam hamd Allah ki, koi mabood nahi, Allah bada.',  hadith:'Most beloved words to Allah. (Muslim)',                                               badge:'sahih',     cat:'all'     },
    { id:'z9',  name:'Most Powerful Zikr', urdu:'سب سے طاقتور',   arabic:'لَا إِلٰهَ إِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ', roman:"La ilaha illallahu wahdahu la sharika lah, lahul mulku...", meaning:'Allah akela, koi shareek nahi, usi ki badshahat, woh qadir hai.',     hadith:'100× = reward of freeing 10 slaves, 100 good deeds, 100 sins erased. (Bukhari)',     badge:'powerful',  cat:'morning' },
    { id:'z10', name:'Sayyidul Istighfar', urdu:'استغفار کا سردار', arabic:'اللّٰهُمَّ أَنْتَ رَبِّي لَا إِلٰهَ إِلَّا أَنْتَ خَلَقْتَنِي وَأَنَا عَبْدُكَ',                                      roman:'Allahumma anta rabbi la ilaha illa anta, khalaqtani wa ana abduka', meaning:'Ae Allah Tu mera Rab hai, Tu ne mujhe banaya, main tera banda hun.', hadith:'Read morning/evening → if you die that day → Jannah guaranteed! (Bukhari)',            badge:'powerful',  cat:'morning' },
    { id:'z11', name:'Astaghfar Full',     urdu:'مکمل استغفار',   arabic:'أَسْتَغْفِرُ اللّٰهَ الْعَظِيمَ الَّذِي لَا إِلٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ',               roman:'Astaghfirullahal azeemal ladhi la ilaha illa huwal hayyul qayyum wa atubu ilaih', meaning:'Main Allah se maghfirat maangta hun jis ke siwa koi ilah nahi.', hadith:'Forgiven even if he fled from battle. (Abu Dawud, Tirmidhi)',                         badge:'sahih',     cat:'all'     },
    { id:'z12', name:'SubhanAllah 100×',   urdu:'سبحان اللہ سو بار', arabic:'سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ',                                                                                        roman:'SubhanAllahi wa bihamdihi',            meaning:'Allah paak hai uski hamd ke saath.',                                        hadith:'100× morning/evening → sins forgiven even if like ocean foam. (Bukhari, Muslim)',     badge:'powerful',  cat:'morning' },
    { id:'z13', name:'Protection Zikr',    urdu:'حفاظتی ذکر',    arabic:'بِسْمِ اللّٰهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ',                             roman:"Bismillahil ladhi la yadurru ma'asmihi shay'un fil ardi wa la fis sama'i", meaning:'Allah ke naam ke saath, koi cheez nuqsan nahi de sakti.',             hadith:'3× morning/evening → nothing harms you all day. (Abu Dawud — Sahih)',                badge:'protection',cat:'morning' },
    { id:'z14', name:'Tasbih Fatimah',     urdu:'تسبیح فاطمہ',    arabic:'سُبْحَانَ اللّٰهِ ٣٣ · الْحَمْدُ لِلّٰهِ ٣٣ · اللّٰهُ أَكْبَرُ ٣٤',                                                       roman:'SubhanAllah ×33 · Alhamdulillah ×33 · Allahu Akbar ×34 = 100',meaning:'Allah paak (33), tamam hamd (33), Allah bada (34). Total 100.',           hadith:'Better than a servant. Say every night before sleeping. (Bukhari, Muslim)',           badge:'sahih',     cat:'evening' },
    { id:'z15', name:'Ya Hayyu Ya Qayyum', urdu:'یا حی یا قیوم',  arabic:'يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ',                                                                       roman:'Ya Hayyu Ya Qayyum birahmatika astaghees', meaning:'Ae Zindah! Ae Qayam! Teri rehmat se fariyaad karta hun.',             hadith:'Prophet ﷺ said this constantly. Excellent in distress. (Tirmidhi)',                   badge:'powerful',  cat:'all'     },
    { id:'z16', name:'Dua of Yunus ﷺ',     urdu:'دعا یونس',       arabic:'لَا إِلٰهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',                                                 roman:'La ilaha illa anta subhanaka inni kuntu minaz zalimeen', meaning:'Ae Allah Tu paak hai, beshak main zalimon mein se tha.',                 hadith:'No Muslim calls this in hardship except Allah responds. (Tirmidhi — Sahih)',          badge:'protection',cat:'all'     },
    { id:'z17', name:'Daily Istighfar',    urdu:'روزانہ استغفار',  arabic:'أَسْتَغْفِرُ اللّٰهَ وَأَتُوبُ إِلَيْهِ',                                                                               roman:'Astaghfirullaha wa atubu ilaih',        meaning:'Main Allah se maghfirat maangta hun aur usi ki taraf ruju karta hun.',       hadith:'Prophet ﷺ sought forgiveness 70+ times daily. (Bukhari)',                             badge:'sahih',     cat:'all'     },
    { id:'z18', name:'Allahu Akbar Kabira',urdu:'اللہ اکبر کبیرا', arabic:'اللّٰهُ أَكْبَرُ كَبِيرًا وَالْحَمْدُ لِلّٰهِ كَثِيرًا وَسُبْحَانَ اللّٰهِ بُكْرَةً وَأَصِيلًا',                        roman:'Allahu akbar kabeera walhamdulillahi katheera wa SubhanAllahi bukratan wa aseela', meaning:'Allah bahut bada hai, bahut hamd Allah ki, Allah paak hai.',          hadith:'This opened the doors of heaven — Prophet ﷺ was amazed. (Muslim)',                   badge:'powerful',  cat:'morning' },
    { id:'z19', name:'Morning Zikr',       urdu:'صبح کا ذکر',     arabic:'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلّٰهِ وَالْحَمْدُ لِلّٰهِ',                                                           roman:'Asbahna wa asbahal mulku lillahi walhamdulillah', meaning:'Hum ne subah ki aur badshahi Allah ki aur tamam hamd Allah ki.',         hadith:'Authentic morning adhkar of the Prophet ﷺ. (Abu Dawud)',                              badge:'sahih',     cat:'morning' },
    { id:'z20', name:'Evening Zikr',       urdu:'شام کا ذکر',     arabic:'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلّٰهِ وَالْحَمْدُ لِلّٰهِ',                                                           roman:'Amsayna wa amsal mulku lillahi walhamdulillah', meaning:'Hum ne shaam ki aur badshahi Allah ki aur tamam hamd Allah ki.',         hadith:'Authentic evening adhkar of the Prophet ﷺ. (Abu Dawud)',                              badge:'sahih',     cat:'evening' },
    { id:'z21', name:'Dua for Aafiyah',    urdu:'عافیت کی دعا',   arabic:'اللّٰهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ',                                    roman:"Allahumma inni as'alukal afwa wal afiyata fid dunya wal akhirah", meaning:'Ae Allah! Main maafi aur aafiyat maangta hun dunya aur aakhirat mein.',    hadith:'Nothing better than forgiveness and good health. (Ibn Majah)',                        badge:'sahih',     cat:'morning' },
    { id:'z22', name:'Against Anxiety',    urdu:'پریشانی کی دعا', arabic:'اللّٰهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ وَالْعَجْزِ وَالْكَسَلِ',                                     roman:"Allahumma inni a'udhu bika minal hammi wal hazani wal ajzi wal kasal", meaning:'Ae Allah! Main gham, parishan, kamzori, kaslat se teri panaah maangta hun.', hadith:'Prophet ﷺ read this regularly for anxiety. (Bukhari)',                             badge:'protection',cat:'all'     },
    { id:'z23', name:'Tawbah Dua',         urdu:'توبہ کی دعا',    arabic:'رَبِّ إِنِّي ظَلَمْتُ نَفْسِي فَاغْفِرْ لِي',                                                                           roman:'Rabbi inni zalamtu nafsi faghfir li',   meaning:'Ae Rab! Main ne apne aap par zulm kiya, mujhe maaf kar.',                   hadith:'Taught by Prophet ﷺ to Abu Bakr Siddiq ؓ personally. (Bukhari)',                     badge:'sahih',     cat:'all'     },
    { id:'z24', name:'Durood Short',        urdu:'مختصر درود',     arabic:'اللّٰهُمَّ صَلِّ وَسَلِّمْ عَلَىٰ نَبِيِّنَا مُحَمَّدٍ',                                                               roman:'Allahumma salli wa sallim ala nabiyyina Muhammad', meaning:'Ae Allah! Hamare Nabi ﷺ par darood aur salam nazil farma.',              hadith:'1 Darood → 10 mercies, 10 sins erased, 10 ranks raised. (Muslim)',                   badge:'powerful',  cat:'all'     },
    { id:'z25', name:'Surah Ikhlas Zikr',  urdu:'اللہ صمد',       arabic:'اللّٰهُ الصَّمَدُ · لَمْ يَلِدْ وَلَمْ يُولَدْ · وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ',                                   roman:'Allahus samad · lam yalid wa lam yoolad · wa lam yakullahu kufuwan ahad', meaning:'Allah behtaz, na baap na beta, koi barabar nahi. (Surah Ikhlas)', hadith:'Surah Ikhlas once = one-third of the Quran. (Bukhari)',                                badge:'powerful',  cat:'all'     },
    { id:'z26', name:'Ya Lateef Ya Khabeer',urdu:'یا لطیف یا خبیر',arabic:'يَا لَطِيفُ يَا خَبِيرُ',                                                                                              roman:'Ya Lateef, Ya Khabeer',                meaning:'Ae Latif (subtle)! Ae Khabeer (all-aware)!',                                hadith:'Opens doors of rizq and hidden blessings from Allah.',                                badge:'powerful',  cat:'all'     },
  ],

  darood: [
    { id:'d1', name:'Darood Ibrahim',   urdu:'درود ابراہیم',   arabic:'اللّٰهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَعَلَىٰ آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَىٰ إِبْرَاهِيمَ وَعَلَىٰ آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ', roman:'Allahumma salli ala Muhammadin wa ala aali Muhammadin kama sallaita ala Ibrahima...', meaning:'Ae Allah, Muhammad ﷺ aur unki aal par rehmat farma jis tarah Ibrahim par farmaya.', hadith:'Most authentic Darood — recited in every Salah. (Bukhari)', badge:'powerful', cat:'all' },
    { id:'d2', name:'Darood Tunajjina', urdu:'درود تنجینہ',   arabic:'اللّٰهُمَّ صَلِّ عَلَىٰ سَيِّدِنَا مُحَمَّدٍ صَلَاةً تُنَجِّينَا بِهَا مِنْ جَمِيعِ الْأَهْوَالِ وَالْآفَاتِ', roman:"Allahumma salli ala Sayyidina Muhammadin salatan tunajjina biha min jamee'il ahwali wal aafat", meaning:'Ae Allah aisi rehmat jo tamam aafat se bachaye.', hadith:'Recite 1000× for relief from major calamities.', badge:'protection', cat:'all' },
    { id:'d3', name:'Darood Shifa',     urdu:'درود شفا',      arabic:'اللّٰهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ طِبِّ الْقُلُوبِ وَدَوَائِهَا', roman:"Allahumma salli ala Muhammadin tibbil quloob wa dawa'iha", meaning:'Ae Allah rehmat farma jo dilon ki dawai hain.', hadith:'Recite for healing of body and heart.', badge:'protection', cat:'all' },
    { id:'d4', name:'Shortest Darood',  urdu:'مختصر درود',    arabic:'اللّٰهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ', roman:'Allahumma salli ala Muhammad', meaning:'Ae Allah, Muhammad ﷺ par rehmat nazil farma.', hadith:'1 Darood → Allah sends 10 mercies. (Muslim)', badge:'sahih', cat:'all' },
    { id:'d5', name:'Darood Noor',      urdu:'درود نور',      arabic:'اللّٰهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ نُورِ الْأَنْوَارِ وَسِرِّ الْأَسْرَارِ', roman:"Allahumma salli ala Muhammadin nooril anwari wa sirril asrar", meaning:'Ae Allah rehmat farma jo nooron ke noor hain.', hadith:'Recite for spiritual illumination and inner light.', badge:'powerful', cat:'all' },
  ],

  duas: [
    { icon:'🌅', bg:'rgba(201,168,76,0.1)',  name:'Morning Dua',    cat:'Morning', arabic:'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلّٰهِ وَالْحَمْدُ لِلّٰهِ وَلَا إِلٰهَ إِلَّا اللّٰهُ', roman:'Asbahna wa asbahal mulku lillahi walhamdulillah wa la ilaha illallah', meaning:'Hum ne subah ki, badshahi aur hamd Allah ki hai.' },
    { icon:'🌙', bg:'rgba(13,107,78,0.15)',   name:'Evening Dua',    cat:'Evening', arabic:'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلّٰهِ وَالْحَمْدُ لِلّٰهِ', roman:'Amsayna wa amsal mulku lillahi walhamdulillah', meaning:'Hum ne shaam ki, badshahi aur hamd Allah ki hai.' },
    { icon:'😴', bg:'rgba(100,80,180,0.12)',  name:'Before Sleep',   cat:'Sleep',   arabic:'بِاسْمِكَ اللّٰهُمَّ أَمُوتُ وَأَحْيَا', roman:'Bismikallahuma amutu wa ahya', meaning:'Tere naam ke saath ae Allah main marta aur jeeta hun.' },
    { icon:'☀️', bg:'rgba(201,168,76,0.12)', name:'Upon Waking',    cat:'Sleep',   arabic:'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ', roman:"Alhamdulillahil ladhi ahyana ba'da ma amatana wa ilayhil nushur", meaning:'Shukar Allah ka jo zindagi di, wahi dobara uthane wala hai.' },
    { icon:'🍽️', bg:'rgba(13,107,78,0.15)', name:'Before Eating',  cat:'Daily',   arabic:'بِسْمِ اللّٰهِ وَعَلَىٰ بَرَكَةِ اللّٰهِ', roman:'Bismillahi wa ala barakatillah', meaning:'Allah ke naam ke saath aur Allah ki barakat ke saath.' },
    { icon:'✅', bg:'rgba(46,204,113,0.1)',   name:'After Eating',   cat:'Daily',   arabic:'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ', roman:"Alhamdulillahil ladhi at'amana wa saqana wa ja'alana muslimeen", meaning:'Shukar Allah ka jisne khilaya, pilaya, musalman banaya.' },
    { icon:'🚶', bg:'rgba(100,80,180,0.1)',   name:'Leaving Home',   cat:'Travel',  arabic:'بِسْمِ اللّٰهِ تَوَكَّلْتُ عَلَى اللّٰهِ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللّٰهِ', roman:'Bismillahi tawakkaltu alallahi wa la hawla wa la quwwata illa billah', meaning:'Allah ke naam ke saath, Allah par tawakkul karta hun.' },
    { icon:'🏠', bg:'rgba(201,168,76,0.1)',   name:'Entering Home',  cat:'Daily',   arabic:'اللّٰهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلِجِ وَخَيْرَ الْمَخْرَجِ', roman:"Allahumma inni as'aluka khayral mawliji wa khayral makhraj", meaning:'Ae Allah andar aane aur bahar nikalne ki khair maangta hun.' },
    { icon:'💊', bg:'rgba(200,100,100,0.1)',  name:'For Healing',    cat:'Special', arabic:'أَذْهِبِ الْبَأْسَ رَبَّ النَّاسِ وَاشْفِ أَنْتَ الشَّافِي', roman:"Adh'hibil ba'sa rabban nasi washfi anta ash-shafi", meaning:'Ae logon ke Rab! takleef door kar, shifa de — teri shifa kaafi hai.' },
    { icon:'😰', bg:'rgba(100,80,180,0.1)',   name:'For Anxiety',    cat:'Special', arabic:'اللّٰهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ', roman:"Allahumma inni a'udhu bika minal hammi wal hazan", meaning:'Ae Allah main gham aur parishan se teri panaah maangta hun.' },
    { icon:'🧳', bg:'rgba(100,160,200,0.1)', name:'Travel Dua',     cat:'Travel',  arabic:'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هٰذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ', roman:"SubhaanAlladhi sakh-khara lana hadha wa ma kunna lahu muqrineen", meaning:'Paak hai woh jo ne is sawari ko musakhkhar kiya.' },
    { icon:'🌧️', bg:'rgba(100,180,220,0.1)', name:'During Rain',    cat:'Special', arabic:'اللّٰهُمَّ صَيِّبًا نَافِعًا', roman:"Allahumma sayyiban nafi'an", meaning:'Ae Allah! Nafay mand baarish nazil farma.' },
  ],

  names: [
    {n:1,a:'اللّٰهُ',e:'Allah',m:'The One God'},{n:2,a:'الرَّحْمٰنُ',e:'Ar-Rahman',m:'The Most Gracious'},{n:3,a:'الرَّحِيمُ',e:'Ar-Raheem',m:'The Most Merciful'},{n:4,a:'الْمَلِكُ',e:'Al-Malik',m:'The King'},{n:5,a:'الْقُدُّوسُ',e:'Al-Quddus',m:'The Most Holy'},
    {n:6,a:'السَّلَامُ',e:'As-Salam',m:'Source of Peace'},{n:7,a:'الْمُؤْمِنُ',e:"Al-Mu'min",m:'Guardian of Faith'},{n:8,a:'الْمُهَيْمِنُ',e:'Al-Muhaymin',m:'The Protector'},{n:9,a:'الْعَزِيزُ',e:'Al-Aziz',m:'The Almighty'},{n:10,a:'الْجَبَّارُ',e:'Al-Jabbar',m:'The Compeller'},
    {n:11,a:'الْمُتَكَبِّرُ',e:'Al-Mutakabbir',m:'The Supreme'},{n:12,a:'الْخَالِقُ',e:'Al-Khaliq',m:'The Creator'},{n:13,a:'الْبَارِئُ',e:"Al-Bari'",m:'The Evolver'},{n:14,a:'الْمُصَوِّرُ',e:'Al-Musawwir',m:'The Fashioner'},{n:15,a:'الْغَفَّارُ',e:'Al-Ghaffar',m:'The Forgiving'},
    {n:16,a:'الْقَهَّارُ',e:'Al-Qahhar',m:'The Subduer'},{n:17,a:'الْوَهَّابُ',e:'Al-Wahhab',m:'The Bestower'},{n:18,a:'الرَّزَّاقُ',e:'Ar-Razzaq',m:'The Sustainer'},{n:19,a:'الْفَتَّاحُ',e:'Al-Fattah',m:'The Opener'},{n:20,a:'الْعَلِيمُ',e:'Al-Alim',m:'The All-Knowing'},
    {n:21,a:'الْقَابِضُ',e:'Al-Qabid',m:'The Restrainer'},{n:22,a:'الْبَاسِطُ',e:'Al-Basit',m:'The Extender'},{n:23,a:'الْخَافِضُ',e:'Al-Khafid',m:'The Abaser'},{n:24,a:'الرَّافِعُ',e:"Ar-Rafi'",m:'The Exalter'},{n:25,a:'الْمُعِزُّ',e:"Al-Mu'izz",m:'The Honourer'},
    {n:26,a:'الْمُذِلُّ',e:'Al-Mudhill',m:'The Humiliator'},{n:27,a:'السَّمِيعُ',e:'As-Sami',m:'The All-Hearing'},{n:28,a:'الْبَصِيرُ',e:'Al-Basir',m:'The All-Seeing'},{n:29,a:'الْحَكَمُ',e:'Al-Hakam',m:'The Judge'},{n:30,a:'الْعَدْلُ',e:"Al-'Adl",m:'The Just'},
    {n:31,a:'اللَّطِيفُ',e:'Al-Latif',m:'The Subtle One'},{n:32,a:'الْخَبِيرُ',e:'Al-Khabir',m:'The All-Aware'},{n:33,a:'الْحَلِيمُ',e:'Al-Halim',m:'The Forbearing'},{n:34,a:'الْعَظِيمُ',e:'Al-Azim',m:'The Magnificent'},{n:35,a:'الْغَفُورُ',e:'Al-Ghafur',m:'The Forgiving'},
    {n:36,a:'الشَّكُورُ',e:'Ash-Shakur',m:'The Appreciative'},{n:37,a:'الْعَلِيُّ',e:"Al-'Ali",m:'The Most High'},{n:38,a:'الْكَبِيرُ',e:'Al-Kabir',m:'The Most Great'},{n:39,a:'الْحَفِيظُ',e:'Al-Hafiz',m:'The Preserver'},{n:40,a:'الْمُقِيتُ',e:'Al-Muqit',m:'The Nourisher'},
    {n:41,a:'الْحَسِيبُ',e:'Al-Hasib',m:'The Reckoner'},{n:42,a:'الْجَلِيلُ',e:'Al-Jalil',m:'The Majestic'},{n:43,a:'الْكَرِيمُ',e:'Al-Karim',m:'The Generous'},{n:44,a:'الرَّقِيبُ',e:'Ar-Raqib',m:'The Watchful'},{n:45,a:'الْمُجِيبُ',e:'Al-Mujib',m:'The Responsive'},
    {n:46,a:'الْوَاسِعُ',e:'Al-Wasi',m:'The Encompassing'},{n:47,a:'الْحَكِيمُ',e:'Al-Hakim',m:'The All-Wise'},{n:48,a:'الْوَدُودُ',e:'Al-Wadud',m:'The Loving'},{n:49,a:'الْمَجِيدُ',e:'Al-Majid',m:'The Glorious'},{n:50,a:'الْبَاعِثُ',e:"Al-Ba'ith",m:'The Resurrector'},
    {n:51,a:'الشَّهِيدُ',e:'Ash-Shahid',m:'The Witness'},{n:52,a:'الْحَقُّ',e:'Al-Haqq',m:'The Truth'},{n:53,a:'الْوَكِيلُ',e:'Al-Wakil',m:'The Trustee'},{n:54,a:'الْقَوِيُّ',e:'Al-Qawi',m:'The Most Strong'},{n:55,a:'الْمَتِينُ',e:'Al-Matin',m:'The Firm'},
    {n:56,a:'الْوَلِيُّ',e:'Al-Wali',m:'The Protecting Friend'},{n:57,a:'الْحَمِيدُ',e:'Al-Hamid',m:'The Praiseworthy'},{n:58,a:'الْمُحْصِي',e:'Al-Muhsi',m:'The Counter'},{n:59,a:'الْمُبْدِئُ',e:'Al-Mubdi',m:'The Originator'},{n:60,a:'الْمُعِيدُ',e:"Al-Mu'id",m:'The Restorer'},
    {n:61,a:'الْمُحْيِي',e:'Al-Muhyi',m:'Giver of Life'},{n:62,a:'الْمُمِيتُ',e:'Al-Mumit',m:'Creator of Death'},{n:63,a:'الْحَيُّ',e:'Al-Hayy',m:'The Ever-Living'},{n:64,a:'الْقَيُّومُ',e:'Al-Qayyum',m:'The Self-Subsisting'},{n:65,a:'الْوَاجِدُ',e:'Al-Wajid',m:'The Finder'},
    {n:66,a:'الْمَاجِدُ',e:'Al-Majid',m:'The Noble'},{n:67,a:'الْوَاحِدُ',e:'Al-Wahid',m:'The One'},{n:68,a:'الْأَحَدُ',e:'Al-Ahad',m:'The Unique'},{n:69,a:'الصَّمَدُ',e:'As-Samad',m:'The Eternal'},{n:70,a:'الْقَادِرُ',e:'Al-Qadir',m:'The Able'},
    {n:71,a:'الْمُقْتَدِرُ',e:'Al-Muqtadir',m:'The Powerful'},{n:72,a:'الْمُقَدِّمُ',e:'Al-Muqaddim',m:'The Expediter'},{n:73,a:'الْمُؤَخِّرُ',e:"Al-Mu'akhkhir",m:'The Delayer'},{n:74,a:'الْأَوَّلُ',e:'Al-Awwal',m:'The First'},{n:75,a:'الْآخِرُ',e:'Al-Akhir',m:'The Last'},
    {n:76,a:'الظَّاهِرُ',e:'Az-Zahir',m:'The Manifest'},{n:77,a:'الْبَاطِنُ',e:'Al-Batin',m:'The Hidden'},{n:78,a:'الْوَالِي',e:'Al-Wali',m:'The Governor'},{n:79,a:'الْمُتَعَالِي',e:"Al-Muta'ali",m:'The Most Exalted'},{n:80,a:'الْبَرُّ',e:'Al-Barr',m:'Source of Goodness'},
    {n:81,a:'التَّوَّابُ',e:'At-Tawwab',m:'Acceptor of Repentance'},{n:82,a:'الْمُنْتَقِمُ',e:'Al-Muntaqim',m:'The Avenger'},{n:83,a:'الْعَفُوُّ',e:"Al-'Afuww",m:'The Pardoner'},{n:84,a:'الرَّؤُوفُ',e:"Ar-Ra'uf",m:'The Compassionate'},{n:85,a:'مَالِكُ الْمُلْكِ',e:'Malik-ul-Mulk',m:'Owner of Sovereignty'},
    {n:86,a:'ذُو الْجَلَالِ',e:'Dhul-Jalal',m:'Lord of Majesty'},{n:87,a:'الْمُقْسِطُ',e:'Al-Muqsit',m:'The Equitable'},{n:88,a:'الْجَامِعُ',e:"Al-Jami'",m:'The Gatherer'},{n:89,a:'الْغَنِيُّ',e:'Al-Ghani',m:'The Self-Sufficient'},{n:90,a:'الْمُغْنِي',e:'Al-Mughni',m:'The Enricher'},
    {n:91,a:'الْمَانِعُ',e:"Al-Mani'",m:'The Withholder'},{n:92,a:'الضَّارُّ',e:'Ad-Darr',m:'The Distresser'},{n:93,a:'النَّافِعُ',e:"An-Nafi'",m:'The Propitious'},{n:94,a:'النُّورُ',e:'An-Nur',m:'The Light'},{n:95,a:'الْهَادِي',e:'Al-Hadi',m:'The Guide'},
    {n:96,a:'الْبَدِيعُ',e:"Al-Badi'",m:'The Incomparable'},{n:97,a:'الْبَاقِي',e:'Al-Baqi',m:'The Everlasting'},{n:98,a:'الْوَارِثُ',e:'Al-Warith',m:'The Inheritor'},{n:99,a:'الرَّشِيدُ',e:'Ar-Rashid',m:'Guide to Right Path'},
  ],

  quick: ['SubhanAllah','Alhamdulillah','Allahu Akbar','La ilaha illallah','Astaghfirullah','SubhanAllahi wa bihamdihi','Allahu Akbar Kabira']
};

/* ═══════════════════════════════════════════════════════════
   STATE
═══════════════════════════════════════════════════════════ */
const SK = 'noor_v21';

const DEF = {
  theme:'dark', vibration:true, completionAlert:true, largeArabic:false,
  gcCount:0, gcTarget:33, gcSession:0, gcHistory:[],
  counters:{}, favorites:[], myZikr:[],
  totalLifetime:0, todayCount:0, todayDate:'',
  streak:0, lastDate:null,
  currentTab:'tasbih', currentFilter:'all'
};

let S = {};

function loadState() {
  try { S = Object.assign({}, DEF, JSON.parse(localStorage.getItem(SK) || '{}')); }
  catch(e) { S = Object.assign({}, DEF); }
  // Reset today count if it's a new day
  const today = new Date().toDateString();
  if (S.todayDate !== today) { S.todayCount = 0; S.todayDate = today; }
}

function save() {
  try { localStorage.setItem(SK, JSON.stringify(S)); }
  catch(e) {}
}

function set(k, v) { S[k] = v; save(); }
function upd(o)    { Object.assign(S, o); save(); }

/* ═══════════════════════════════════════════════════════════
   VIBRATION
═══════════════════════════════════════════════════════════ */
function vib(p) {
  if (!S.vibration) return;
  try { navigator.vibrate && navigator.vibrate(p); } catch(e) {}
}

/* ═══════════════════════════════════════════════════════════
   STREAK
═══════════════════════════════════════════════════════════ */
function checkStreak() {
  const today = new Date().toDateString();
  if (!S.lastDate) { upd({ streak:1, lastDate:today }); return; }
  if (S.lastDate === today) return;
  const yest = new Date(); yest.setDate(yest.getDate() - 1);
  upd({ streak: S.lastDate === yest.toDateString() ? S.streak + 1 : 1, lastDate: today });
}

/* ═══════════════════════════════════════════════════════════
   TOAST
═══════════════════════════════════════════════════════════ */
let _tt = null;
function toast(msg) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(_tt);
  _tt = setTimeout(() => el.classList.remove('show'), 2600);
}

/* ═══════════════════════════════════════════════════════════
   GLOBAL COUNTER  — single tap = single count
═══════════════════════════════════════════════════════════ */
function gcTap() {
  const count  = S.gcCount + 1;
  const target = S.gcTarget;
  const hist   = (S.gcHistory || []).slice(); // copy
  hist.push(count);
  if (hist.length > 500) hist.shift();

  upd({
    gcCount: count,
    gcSession: S.gcSession + 1,
    gcHistory: hist,
    totalLifetime: S.totalLifetime + 1,
    todayCount: S.todayCount + 1,
    todayDate: new Date().toDateString()
  });

  checkStreak();
  vib(12);

  // Animate orb
  const orb = document.getElementById('orb');
  if (orb) { orb.classList.remove('pulse'); void orb.offsetWidth; orb.classList.add('pulse'); }

  updateGC();
  updateStats();

  // Completion
  if (count % target === 0) {
    if (orb) { orb.classList.remove('ring'); void orb.offsetWidth; orb.classList.add('ring'); }
    vib([40, 30, 80]);
    if (S.completionAlert) toast(`🎉 MashaAllah! ${count} complete!`);
  }
}

function gcUndo() {
  if (S.gcCount <= 0) { toast('Nothing to undo'); return; }
  const hist = (S.gcHistory || []).slice();
  hist.pop();
  const prev = hist.length > 0 ? hist[hist.length - 1] : 0;
  upd({
    gcCount: prev,
    gcSession: Math.max(0, S.gcSession - 1),
    gcHistory: hist,
    totalLifetime: Math.max(0, S.totalLifetime - 1),
    todayCount: Math.max(0, S.todayCount - 1)
  });
  vib(8);
  updateGC();
  updateStats();
  toast('↩ Undone');
}

function gcReset() {
  upd({ gcCount:0, gcSession:0, gcHistory:[] });
  vib([20, 10, 20]);
  updateGC();
  toast('↺ Counter reset');
}

function gcSetTarget(t) {
  set('gcTarget', t);
  updateGC();
}

function updateGC() {
  const count  = S.gcCount;
  const target = S.gcTarget;
  const sess   = S.gcSession;

  const cEl = document.getElementById('gc-count');
  const pEl = document.getElementById('gc-pbar');
  const tEl = document.getElementById('gc-tgt-lbl');
  const sEl = document.getElementById('gc-sess');

  if (cEl) {
    cEl.textContent = count;
    cEl.classList.remove('bump'); void cEl.offsetWidth; cEl.classList.add('bump');
  }
  if (tEl) tEl.innerHTML = `Target: <span>${target}</span>`;
  if (sEl) sEl.innerHTML = sess > 0 ? `Session: <span>${sess}</span>` : '';
  if (pEl) {
    const cyc = count % target;
    pEl.style.width = (count === 0 ? 0 : cyc === 0 ? 100 : cyc / target * 100) + '%';
  }

  // Sync target buttons
  document.querySelectorAll('[data-gct]').forEach(b => {
    b.classList.toggle('active', parseInt(b.dataset.gct) === target);
  });
}

function updateStats() {
  const streak = S.streak;
  const total  = S.totalLifetime;
  const today  = S.todayCount;

  // Header pills
  el('stat-streak',  streak);
  el('stat-total',   total.toLocaleString());
  el('stat-today',   today);
  // Tasbih section
  el('sk-num',       streak);
  el('sk-total-num', total.toLocaleString());
  // Settings
  el('s-streak-val', `Streak: ${streak} Day${streak !== 1 ? 's' : ''}`);
  el('s-total-val',  `Lifetime: ${total.toLocaleString()}`);
  el('s-today-val',  `Today: ${today}`);
}

function el(id, val) {
  const e = document.getElementById(id);
  if (e) e.textContent = val;
}

/* ═══════════════════════════════════════════════════════════
   PER-ZIKR COUNTER
═══════════════════════════════════════════════════════════ */
function getC(id) {
  if (!S.counters[id]) S.counters[id] = { count:0, target:33, history:[] };
  return S.counters[id];
}
function saveC(id, c) { S.counters[id] = c; save(); }

function zTap(id) {
  const c = getC(id);
  c.count++;
  c.history = (c.history || []);
  c.history.push(c.count);
  if (c.history.length > 200) c.history.shift();
  saveC(id, c);
  upd({ totalLifetime: S.totalLifetime + 1, todayCount: S.todayCount + 1, todayDate: new Date().toDateString() });
  checkStreak();
  updateStats();
  updateZC(id);
  vib(12);

  const btn = document.querySelector(`[data-tap="${id}"]`);
  if (btn) { btn.classList.remove('tap-bump'); void btn.offsetWidth; btn.classList.add('tap-bump'); }

  if (c.count % c.target === 0) {
    vib([30, 20, 60]);
    if (S.completionAlert) toast(`✅ ${c.target}× done! SubhanAllah!`);
  }
}

function zUndo(id) {
  const c = getC(id);
  if (c.count <= 0) { toast('Nothing to undo'); return; }
  c.history = (c.history || []);
  c.history.pop();
  c.count = c.history.length > 0 ? c.history[c.history.length - 1] : 0;
  saveC(id, c);
  upd({ totalLifetime: Math.max(0, S.totalLifetime - 1), todayCount: Math.max(0, S.todayCount - 1) });
  updateStats();
  updateZC(id);
  vib(8);
  toast('↩ Undone');
}

function zReset(id) {
  const c = getC(id);
  c.count = 0; c.history = [];
  saveC(id, c);
  updateZC(id);
  vib([15, 10, 15]);
  toast('↺ Reset');
}

function zSetTarget(id, t, btn) {
  const c = getC(id);
  c.target = t;
  saveC(id, c);
  btn.closest('.mt-row1').querySelectorAll('.mt-btn').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
  updateZC(id);
}

function updateZC(id) {
  const c = getC(id);
  el(`zcnt-${id}`, c.count);
  el(`ztgt-${id}`, c.target);
  const pEl = document.getElementById(`zpb-${id}`);
  const dEl = document.getElementById(`zdone-${id}`);
  if (pEl) {
    const cyc = c.count % c.target;
    pEl.style.width = (c.count === 0 ? 0 : cyc === 0 ? 100 : cyc / c.target * 100) + '%';
  }
  if (dEl) dEl.classList.toggle('show', c.count > 0 && c.count % c.target === 0);
}

/* ═══════════════════════════════════════════════════════════
   FAVORITES
═══════════════════════════════════════════════════════════ */
function toggleFav(id) {
  const favs = (S.favorites || []).slice();
  const i = favs.indexOf(id);
  if (i === -1) { favs.push(id); toast('❤️ Added to favorites'); vib(15); }
  else          { favs.splice(i, 1); toast('Removed from favorites'); }
  set('favorites', favs);
  const btn = document.querySelector(`[data-fav="${id}"]`);
  if (btn) { const on = favs.includes(id); btn.textContent = on ? '❤️' : '♡'; btn.classList.toggle('on', on); }
  document.querySelector(`[data-fav="${id}"]`)?.closest('.zcard')?.classList.toggle('faved', favs.includes(id));
}

/* ═══════════════════════════════════════════════════════════
   MY ZIKR
═══════════════════════════════════════════════════════════ */
function saveMyZikr() {
  const arabic  = (document.getElementById('my-arabic')?.value  || '').trim();
  const roman   = (document.getElementById('my-roman')?.value   || '').trim();
  const meaning = (document.getElementById('my-meaning')?.value || '').trim();
  const name    = (document.getElementById('my-name')?.value    || '').trim() || 'My Zikr';
  if (!arabic) { toast('⚠️ Arabic text is required'); return; }

  const list = [...(S.myZikr || []), { id:'my_' + Date.now(), name, urdu:'میرا ذکر', arabic, roman, meaning, hadith:'Added by user', badge:'sahih', cat:'all', custom:true }];
  set('myZikr', list);
  ['my-arabic','my-roman','my-meaning','my-name'].forEach(id => { const e = document.getElementById(id); if(e) e.value=''; });
  toast('✅ Zikr saved!');
  vib([20, 10, 40]);
  renderMyZikr();
}

function deleteMyZikr(id) {
  set('myZikr', (S.myZikr || []).filter(z => z.id !== id));
  renderMyZikr();
  toast('Deleted');
}

/* ═══════════════════════════════════════════════════════════
   BUILD ZIKR CARD HTML
═══════════════════════════════════════════════════════════ */
function badgeCls(b) { return b==='powerful'?'b-powerful':b==='protection'?'b-protect':'b-sahih'; }
function badgeLbl(b) { return b==='powerful'?'⭐ Power':b==='protection'?'🛡 Guard':'Sahih'; }

function buildCard(z, i, showDel = false) {
  const c = getC(z.id);
  const isFav = (S.favorites||[]).includes(z.id);
  const cyc = c.count % c.target;
  const pct = c.count === 0 ? 0 : cyc === 0 ? 100 : cyc / c.target * 100;
  const done = c.count > 0 && c.count % c.target === 0;
  const arabicSize = S.largeArabic ? 'font-size:clamp(22px,5.5vw,32px)' : '';

  return `<div class="zcard${isFav?' faved':''}" style="animation-delay:${Math.min(i*0.04,0.5)}s">
    <div class="ztop">
      <div class="znum">${i+1}</div>
      <div class="zmeta">
        <div class="zname">${z.name}</div>
        <div class="zurdu">${z.urdu}</div>
      </div>
      <div class="zacts">
        <span class="badge ${badgeCls(z.badge)}">${badgeLbl(z.badge)}</span>
        ${showDel
          ? `<button class="del-btn" data-del="${z.id}" title="Delete">🗑️</button>`
          : `<button class="fav-btn${isFav?' on':''}" data-fav="${z.id}" title="Favorite">${isFav?'❤️':'♡'}</button>`}
      </div>
    </div>
    <div class="zarabic"><div class="at" style="${arabicSize}">${z.arabic}</div></div>
    <div class="zbody">
      ${z.roman   ? `<div class="zroman">${z.roman}</div>`   : ''}
      ${z.meaning ? `<div class="zmeaning">${z.meaning}</div>` : ''}
      <div class="zhadith">${z.hadith}</div>
      <div class="mini-tsb">
        <div class="mt-row1">
          <button class="mt-btn${c.target===11?' on':''}" data-id="${z.id}" data-t="11">11</button>
          <button class="mt-btn${c.target===33?' on':''}" data-id="${z.id}" data-t="33">33</button>
          <button class="mt-btn${c.target===99?' on':''}" data-id="${z.id}" data-t="99">99</button>
          <span class="mt-done${done?' show':''}" id="zdone-${z.id}">✓ Done!</span>
        </div>
        <div class="mt-row2">
          <div class="mt-cnt" id="zcnt-${z.id}">${c.count}</div>
          <div class="mt-of">/ <span id="ztgt-${z.id}">${c.target}</span></div>
          <button class="mt-undo" data-undo="${z.id}" title="Undo">↩</button>
          <button class="mt-reset" data-rst="${z.id}" title="Reset">↺</button>
          <button class="mt-tap" data-tap="${z.id}">📿</button>
        </div>
        <div class="mt-pb"><div class="mt-pb-fill" id="zpb-${z.id}" style="width:${pct}%"></div></div>
      </div>
    </div>
  </div>`;
}

/* ═══════════════════════════════════════════════════════════
   RENDER LISTS — use event delegation (not inline onclick)
═══════════════════════════════════════════════════════════ */
function renderZList(data, containerId, showDel = false) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!data || !data.length) {
    el.innerHTML = `<div class="empty"><div class="ei">🔍</div><h3>No results</h3><p>Try a different filter</p></div>`;
    return;
  }
  el.innerHTML = data.map((z, i) => buildCard(z, i, showDel)).join('');
  data.forEach(z => updateZC(z.id));
}

// Delegate ALL zikr-card events — no inline onclick needed
function delegateZikrEvents(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.addEventListener('click', e => {
    const tap   = e.target.closest('[data-tap]');
    const undo  = e.target.closest('[data-undo]');
    const rst   = e.target.closest('[data-rst]');
    const fav   = e.target.closest('[data-fav]');
    const del   = e.target.closest('[data-del]');
    const mtBtn = e.target.closest('.mt-btn');

    if (tap)   { e.stopPropagation(); zTap(tap.dataset.tap); }
    if (undo)  { e.stopPropagation(); zUndo(undo.dataset.undo); }
    if (rst)   { e.stopPropagation(); zReset(rst.dataset.rst); }
    if (fav)   { e.stopPropagation(); toggleFav(fav.dataset.fav); }
    if (del)   { e.stopPropagation(); deleteMyZikr(del.dataset.del); }
    if (mtBtn && !tap && !undo && !rst) {
      e.stopPropagation();
      const id = mtBtn.dataset.id;
      const t  = parseInt(mtBtn.dataset.t);
      if (id && t) zSetTarget(id, t, mtBtn);
    }
  });
}

function filterAndRender() {
  const q = (document.getElementById('zikr-search')?.value || '').toLowerCase().trim();
  const f = S.currentFilter || 'all';
  const favs = S.favorites || [];
  let list = DATA.zikr;
  if (f === 'favorites') list = list.filter(z => favs.includes(z.id));
  else if (f !== 'all')  list = list.filter(z => z.cat === f || z.badge === f);
  if (q) list = list.filter(z =>
    z.name.toLowerCase().includes(q) || z.roman.toLowerCase().includes(q) || z.meaning.toLowerCase().includes(q)
  );
  renderZList(list, 'zikr-list');
}

function renderMyZikr() {
  const list = S.myZikr || [];
  const container = document.getElementById('my-zikr-list');
  if (!container) return;
  if (!list.length) {
    container.innerHTML = `<div class="empty"><div class="ei">📿</div><h3>No custom zikr yet</h3><p>Add your first one above</p></div>`;
    return;
  }
  container.innerHTML = list.map((z, i) => buildCard(z, i, true)).join('');
  list.forEach(z => updateZC(z.id));
}

function renderDuas() {
  const el = document.getElementById('dua-list');
  if (!el) return;
  el.innerHTML = DATA.duas.map((d, i) => `
    <div class="dua-card" id="dua-${i}">
      <div class="dua-hdr" data-dua="${i}">
        <div class="dua-ico" style="background:${d.bg}">${d.icon}</div>
        <div class="dua-ti"><h3>${d.name}</h3><p>${d.cat}</p></div>
        <button class="dua-tog" data-dua="${i}">▾</button>
      </div>
      <div class="dua-body">
        <div class="dua-arabic">${d.arabic}</div>
        <div class="dua-roman">${d.roman}</div>
        <div class="dua-mean">${d.meaning}</div>
      </div>
    </div>`).join('');
}

function renderNames(list) {
  const el = document.getElementById('names-grid');
  if (!el) return;
  el.innerHTML = (list || DATA.names).map(n => `
    <div class="name-card" data-tip="${n.e} — ${n.m}">
      <div class="nc-num">${n.n}</div>
      <div class="nc-ar">${n.a}</div>
      <div class="nc-en">${n.e}</div>
      <div class="nc-me">${n.m}</div>
    </div>`).join('');
}

function renderQuick() {
  const el = document.getElementById('quick-list');
  if (!el) return;
  el.innerHTML = DATA.quick.map(q => `<button class="q-pill" data-q="${q}">${q}</button>`).join('');
}

/* ═══════════════════════════════════════════════════════════
   TABS
═══════════════════════════════════════════════════════════ */
function switchTab(tab) {
  set('currentTab', tab);
  document.querySelectorAll('.sec').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.ntab').forEach(t => t.classList.remove('active'));
  document.getElementById(`sec-${tab}`)?.classList.add('active');
  document.querySelector(`[data-tab="${tab}"]`)?.classList.add('active');

  switch (tab) {
    case 'tasbih':   updateGC(); updateStats(); renderQuick(); break;
    case 'adhkar':   filterAndRender(); break;
    case 'darood':   renderZList(DATA.darood, 'darood-list'); break;
    case 'duas':     renderDuas(); break;
    case 'names':    renderNames(); break;
    case 'myzikr':   renderMyZikr(); break;
    case 'settings':
      const tt = document.getElementById('theme-tog');
      const vt = document.getElementById('vib-tog');
      const at = document.getElementById('alert-tog');
      const lt = document.getElementById('arabic-size-tog');
      if (tt) tt.checked = S.theme === 'light';
      if (vt) vt.checked = S.vibration !== false;
      if (at) at.checked = S.completionAlert !== false;
      if (lt) lt.checked = S.largeArabic === true;
      updateStats();
      break;
  }
  window.scrollTo({ top:0, behavior:'smooth' });
}

/* ═══════════════════════════════════════════════════════════
   THEME & APPEARANCE
═══════════════════════════════════════════════════════════ */
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  set('theme', t);
  const m = document.querySelector('meta[name=theme-color]');
  if (m) m.content = t === 'light' ? '#f2ede4' : '#0d6b4e';
}

function applyLargeArabic(on) {
  document.body.classList.toggle('large-arabic', on);
  set('largeArabic', on);
}

/* ═══════════════════════════════════════════════════════════
   RESET ALL
═══════════════════════════════════════════════════════════ */
function resetAll() {
  if (!confirm('Reset ALL counters, streak and session? Cannot be undone.')) return;
  upd({ gcCount:0, gcSession:0, gcHistory:[], counters:{}, totalLifetime:0, todayCount:0, streak:0 });
  updateGC(); updateStats();
  const t = S.currentTab;
  if (t === 'adhkar')  filterAndRender();
  if (t === 'darood')  renderZList(DATA.darood, 'darood-list');
  if (t === 'myzikr')  renderMyZikr();
  toast('🔄 All counters reset');
  vib([20,15,20]);
}

/* ═══════════════════════════════════════════════════════════
   PWA INSTALL
═══════════════════════════════════════════════════════════ */
let _prompt = null;

function initPWA() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./service-worker.js').catch(() => {});
  }
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    _prompt = e;
    setTimeout(() => { if (_prompt) document.getElementById('inst-banner')?.classList.add('show'); }, 5000);
  });
  window.addEventListener('appinstalled', () => {
    document.getElementById('inst-banner')?.classList.remove('show');
    toast('🎉 Noor installed successfully!');
  });
}

function triggerInstall() {
  if (!_prompt) { toast('Open in Chrome or Edge to install'); return; }
  _prompt.prompt();
  _prompt.userChoice.then(r => { if (r.outcome === 'accepted') toast('✅ Installing...'); _prompt = null; });
  document.getElementById('inst-banner')?.classList.remove('show');
}

/* ═══════════════════════════════════════════════════════════
   BOOT — all event binding happens ONCE here
═══════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  loadState();
  applyTheme(S.theme || 'dark');
  applyLargeArabic(S.largeArabic || false);
  checkStreak();

  // ── NAV TABS ──────────────────────────────────────────
  document.querySelectorAll('[data-tab]').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // ── GLOBAL COUNTER ─────────────────────────────────────
  // Bound ONCE via addEventListener — no onclick in HTML
  document.getElementById('orb')     ?.addEventListener('click', gcTap);
  document.getElementById('gc-undo') ?.addEventListener('click', gcUndo);
  document.getElementById('gc-reset')?.addEventListener('click', gcReset);

  // Target preset buttons
  document.querySelectorAll('[data-gct]').forEach(btn => {
    btn.addEventListener('click', () => {
      const t = parseInt(btn.dataset.gct);
      document.getElementById('gc-custom').value = '';
      gcSetTarget(t);
    });
  });

  // Custom target input
  document.getElementById('gc-custom')?.addEventListener('change', e => {
    const v = parseInt(e.target.value);
    if (v > 0 && v <= 99999) {
      document.querySelectorAll('[data-gct]').forEach(b => b.classList.remove('active'));
      gcSetTarget(v);
    }
  });

  // Space key = tap
  document.addEventListener('keydown', e => {
    if (e.code === 'Space' && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName)) {
      e.preventDefault();
      if (S.currentTab === 'tasbih') gcTap();
    }
  });

  // Quick zikr picker (event delegation)
  document.getElementById('quick-list')?.addEventListener('click', e => {
    const pill = e.target.closest('.q-pill');
    if (pill) {
      document.getElementById('gc-tgt-lbl').innerHTML = `Counting: <span>${pill.dataset.q}</span>`;
      gcTap();
    }
  });

  // ── ZIKR LIST DELEGATION ───────────────────────────────
  // All zikr card buttons use delegation — zero inline onclick
  delegateZikrEvents('zikr-list');
  delegateZikrEvents('darood-list');
  delegateZikrEvents('my-zikr-list');

  // ── SEARCH ─────────────────────────────────────────────
  document.getElementById('zikr-search')?.addEventListener('input', filterAndRender);

  document.getElementById('darood-search')?.addEventListener('input', e => {
    const q = e.target.value.toLowerCase().trim();
    renderZList(q ? DATA.darood.filter(z => z.name.toLowerCase().includes(q) || z.roman.toLowerCase().includes(q)) : DATA.darood, 'darood-list');
  });

  document.getElementById('names-search')?.addEventListener('input', e => {
    const q = e.target.value.toLowerCase().trim();
    renderNames(q ? DATA.names.filter(n => n.e.toLowerCase().includes(q) || n.m.toLowerCase().includes(q)) : null);
  });

  // ── FILTERS ────────────────────────────────────────────
  document.querySelectorAll('[data-filter]').forEach(btn => {
    btn.addEventListener('click', () => {
      set('currentFilter', btn.dataset.filter);
      document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      filterAndRender();
    });
  });

  // ── DUAS (delegation) ──────────────────────────────────
  document.getElementById('dua-list')?.addEventListener('click', e => {
    const hdr = e.target.closest('[data-dua]');
    if (hdr) document.getElementById(`dua-${hdr.dataset.dua}`)?.classList.toggle('open');
  });

  // ── 99 NAMES (delegation) ──────────────────────────────
  document.getElementById('names-grid')?.addEventListener('click', e => {
    const card = e.target.closest('[data-tip]');
    if (card) toast(card.dataset.tip);
  });

  // ── MY ZIKR ────────────────────────────────────────────
  document.getElementById('add-zikr-btn')?.addEventListener('click', saveMyZikr);

  // ── SETTINGS TOGGLES ───────────────────────────────────
  document.getElementById('theme-tog')?.addEventListener('change', e => {
    applyTheme(e.target.checked ? 'light' : 'dark');
    toast(e.target.checked ? '☀️ Light Mode' : '🌙 Dark Mode');
  });

  document.getElementById('vib-tog')?.addEventListener('change', e => {
    set('vibration', e.target.checked);
    if (e.target.checked) vib([15, 10, 15]);
    toast(e.target.checked ? '📳 Vibration On' : '🔕 Vibration Off');
  });

  document.getElementById('alert-tog')?.addEventListener('change', e => {
    set('completionAlert', e.target.checked);
    toast(e.target.checked ? '🔔 Alerts On' : '🔕 Alerts Off');
  });

  document.getElementById('arabic-size-tog')?.addEventListener('change', e => {
    applyLargeArabic(e.target.checked);
    toast(e.target.checked ? '🔤 Large Arabic On' : '🔤 Normal Arabic');
    // Re-render current zikr list so size applies immediately
    if (S.currentTab === 'adhkar') filterAndRender();
    if (S.currentTab === 'darood') renderZList(DATA.darood, 'darood-list');
  });

  document.getElementById('reset-all')?.addEventListener('click', resetAll);

  // ── INSTALL ────────────────────────────────────────────
  document.getElementById('install-btn')?.addEventListener('click', triggerInstall);
  document.getElementById('inst-now')   ?.addEventListener('click', triggerInstall);
  document.getElementById('inst-dismiss')?.addEventListener('click', () => {
    document.getElementById('inst-banner')?.classList.remove('show');
  });

  // ── SCROLL TOP ─────────────────────────────────────────
  window.addEventListener('scroll', () => {
    document.getElementById('scrtop')?.classList.toggle('show', window.scrollY > 280);
  });
  document.getElementById('scrtop')?.addEventListener('click', () => window.scrollTo({ top:0, behavior:'smooth' }));

  // ── INITIAL RENDER ─────────────────────────────────────
  switchTab(S.currentTab || 'tasbih');
  updateStats();
  initPWA();

  console.log('[Noor v2.1] Ready — Ariyan Mushtaq');
});
